/*jslint node: true */
"use strict";

/* The GM library will keep the aspect ratio  */
var config = function() {
    return {
        width: 640,
        height: 640
    };
};

module.exports = config;
